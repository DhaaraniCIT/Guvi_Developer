<?php
	include 'session.php'
?>

<!doctype html>
<html class="no-js " lang="en">
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://fonts.googleapis.com/css?family=Rancho&display=swap" rel="stylesheet">
	<title>login</title>
 	<link rel="stylesheet" href="style.css">
 	<style type="text/css">
 		#alert
 		{
 			display: none;
 		}
 	</style>>
</head>
<body>
<div class="container">	
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand -->
  <a class="navbar-brand" href="#">GUVI</a>

  <!-- Links -->
  <ul class="navbar-nav ml-auto">
    <li class="nav-item">
      <a class="nav-link" href="home.php">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="logout.php">Logout</a>
    </li>
  </ul>
</nav>
	<div class="jumbotron">
		<h1 class="text-center display-4">Welcome</h1>
		<h1 class="text-center display-2"><?= $name; ?></h1>
		<h1 class="text-center display-4">You are in Our Home page </h1>
		<h1 class="text-center display-4">Thank you <?= $name; ?> for logging in here :)</h1>
		<div class="row">
			<div class="col-lg-4 offset-lg-4 bg-dark rounderd" id="register-box">
				<h2 class="text-center mt-2" id="table">Your Details</h2>
				<table class="table table-striped table-dark">
  <thead>
    <tr>
      <th scope="col">Name</th>
      <th scope="col">Username</th>
      <th scope="col">Email</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td> <?= $name; ?></td>
      <td> <?= $username; ?></td>
      <td> <?= $email; ?></td>
    </tr>
  </tbody>
</table>

			</div>
		</div>
	</div>
</div>
</body>
</html>