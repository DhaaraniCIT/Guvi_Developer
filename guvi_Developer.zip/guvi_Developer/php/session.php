<?php
	session_start();
	require 'config.php';

	$user=$_SESSION['username'];

	$sql=$conn->prepare("SELECT * FROM users WHERE username='$user'   ");
			$sql->execute();
			$result=$sql->get_result();
			$row=$result->fetch_array(MYSQLI_ASSOC);
			$username=$row['username'];
			$name=$row['name'];
			$email=$row['email'];
			$created=$row['date'];

			if(!isset($user))
			{
				header("location:login.php");
			}

	if(isset($_POST['action']) && $_POST['action']=='register1')
	{
		$age=$_POST['age'];
		$phone=$_POST['phone'];
		$phon=preg_replace("/[^0-9]/", "", $phone);
		$phone_no=(int)$phon;
		$date=$_POST['dob'];
		if($age!=NULL && $phone!=NULL && $date!=NULL)
		{
			$stmt=$conn->query("update users set age='$age',dob='$date',phone='$phone_no' WHERE username= '$user' ");
				//$stmt->bind_param("s",$user);
				if($stmt)
				{
					echo"registered successfully";
				}
				else
				{
					echo"somthing is wrong,try again";
				}			
		}
		else
		{
			echo "All feilds should be filled";
		}
		if(file_exists('data.json'))  
           {  
                $current_data = file_get_contents('data.json');  
                $array_data = json_decode($current_data, true);
              
                $extra = array(  
                     'age'               =>     $_POST['age'],  
                     'DOB'          =>     $_POST["dob"],  
                     'phone_no'     =>     $_POST["phone"]
                  
                );  
                $array_data[] = $extra;  
                $final_data = json_encode($array_data); 
           
                if(file_put_contents('data.json', $final_data))  
                {  
                     //$message = "<label class='text-success'>File Appended Success fully</p>"; 
                     echo " ,data entered into json file and DB"; 
                }  
           }  
           else  
           {  
                $error = 'JSON File not exits';  
           }  
	}
	function check_input($data)
	{
		$data=trim($data);
		$data=stripslashes($data);
		$data=htmlspecialchars($data);
		return $data;
	}

	
?>